package GloCiNo;


	public class Konto {
		private String blz;
		private String kontoNr;
		private String name;
		private String bank;
		private Aktion aktion;
		private Spende spende;
		//later we will create a method that take spende and forward it to aktion without saving it in konto class
		
		//getters and setters for variables
		public String getBlz() {
			return blz;
		}
		public void setBlz(String blz) {
			this.blz = blz;
		}
		public String getKontoNr() {
			return kontoNr;
		}
		public void setKontoNr(String kontoNr) {
			this.kontoNr = kontoNr;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getBank() {
			return bank;
		}
		public void setBank(String bank) {
			this.bank = bank;
		}
		public Spende getSpende() {
			return spende;
		}
		public void setSpende(Spende spende) {
			this.spende = spende;
		}
		public Aktion getAktion() {
			return aktion;
		}
		public void setAktion(Aktion aktion) {
			this.aktion = aktion;
		}

	}


