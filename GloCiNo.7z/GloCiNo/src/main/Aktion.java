package GloCiNo;

public class Aktion {
	private String name;
	private String spenden;
	private String spendenziel;


	public String getSpendenziel() {
		return spendenziel;
	}

	public void setSpendenziel(String spendenziel) {
		this.spendenziel = spendenziel;
	}

	public String getSpenden() {
		return spenden;
	}

	public void setSpenden(String spenden) {
		this.spenden = spenden;
	}

	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	
	
	
}
