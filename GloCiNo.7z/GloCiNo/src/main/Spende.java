package GloCiNo;

public class Spende {
	
	private double Betrag;
	private boolean Quitting;
	private String spenderName;
	Status Status = GloCiNo.Status.INBEARBEITUNG;


	public String getSpenderName() {
		return spenderName;
	}


	public void setSpenderName(String spenderName) {
		this.spenderName = spenderName;
	}


	public boolean isQuitting() {
		return Quitting;
	}


	public void setQuitting(boolean quitting) {
		Quitting = quitting;
	}


	public double getBetrag() {
		return Betrag;
	}

	public void setBetrag(double betrag) {
		Betrag = betrag;
	}

}
