package GloCiNo;

public enum Status {
	UBERWIESEN, INBEARBEITUNG;
	
}
